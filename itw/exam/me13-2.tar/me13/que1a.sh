#!/bin/bash
if [ $# -ne 1 ]
then
	echo "Syntax: que1a.sh <directory,link name>"
	exit 1
fi

if [ "$(ls -l /etc | sed -n '/^d/p' | grep ' '$1'')" ]
then
	echo "$1 this is a directory"
elif [ "$(ls -l /etc | sed -n '/^l/p' | grep ' '$1' ')" ]
then
	echo "$1 this is a link"
else
    	echo "this is not a link or directory"
fi
