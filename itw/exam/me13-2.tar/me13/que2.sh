#!/bin/bash
if [ $# -ne 1 ]
then
	echo "Syntax: que2.sh <directoryname>"
	exit 1
fi

for file in $1*
do
	var=$(wc -l $file | awk '$1=="3"' | awk '{print $2}') 
	rm $var
done
