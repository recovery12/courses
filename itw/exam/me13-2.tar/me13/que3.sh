#!/bin/bash
if [ $# -ne 1 ]
then
	echo "Syntax: que3.sh <directoryname>"
	exit 1
fi

var=$(ls -l $1 | sed -n '/^\-/p' | sort -k5nr | head -n5 | awk '{print $9}' 
echo "The first five \n recently modified files are \n" 
ls -lt $1 | sed -n '/^\-/p' | head -n5 | awk '{print $9}')
if [ "$(ls -dl $1 | sed -n '/^d/p')" ]
then 
	echo $var
else 
    	echo "the argument is not a directory"
fi
