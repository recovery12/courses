#!/bin/bash
if [ $# -ne 1 ]
then
	echo "Synatx: user.sh <username>"
	exit 1
fi

if [ $(cat /etc/passwd | awk -F: '$1=="'$1'"') ]
then
	echo "It's a user"
else
    	echo "It's not a user"
fi
